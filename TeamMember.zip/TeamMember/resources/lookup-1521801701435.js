(function(window, undefined) {
  var dictionary = {
    "29b35f86-a9fe-4bf0-bf63-43cf6b35b401": "Isi Log",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Team Member",
    "05e69578-a5aa-4748-aee2-5fe0840d432a": "Log",
    "71bbe662-992f-44d0-8b0b-c5c392622a9d": "Unduh-Tagihan",
    "b238018e-ea21-46aa-b337-7158e690b129": "Hapus Log",
    "4ac73443-4d7a-4677-a1f6-7f079f04ebe9": "Riwayat Log",
    "774ab099-1f49-4fb6-956e-9555fa165ca8": "Unduh-Rekap Log",
    "5287e2af-7673-44fa-aeb6-d41e31e33c54": "Ubah Log",
    "b0ee18de-3eed-4a16-86e4-f72827afa275": "Lihat Log",
    "e73b655d-d3ec-4dcc-a55c-6e0293422bde": "960 grid - 16 columns",
    "ef07b413-721c-418e-81b1-33a7ed533245": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);