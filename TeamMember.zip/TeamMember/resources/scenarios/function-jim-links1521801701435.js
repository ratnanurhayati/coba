(function(window, undefined) {

  var jimLinks = {
    "29b35f86-a9fe-4bf0-bf63-43cf6b35b401" : {
    },
    "05e69578-a5aa-4748-aee2-5fe0840d432a" : {
    },
    "71bbe662-992f-44d0-8b0b-c5c392622a9d" : {
    },
    "b238018e-ea21-46aa-b337-7158e690b129" : {
    },
    "774ab099-1f49-4fb6-956e-9555fa165ca8" : {
    },
    "5287e2af-7673-44fa-aeb6-d41e31e33c54" : {
    },
    "b0ee18de-3eed-4a16-86e4-f72827afa275" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);