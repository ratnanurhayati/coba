(function(window, undefined) {

  var jimLinks = {
    "5503c96f-f2c9-4ad0-9cad-dd59af748f5f" : {
    },
    "8e4d9e0e-02bc-4c64-a280-5b613bb0961c" : {
    },
    "7a949020-3324-4dbe-a2fc-0fc25f82a7dc" : {
    },
    "f35c7fd6-45ab-4a15-a9a2-215dfdd7b0f9" : {
    },
    "add40d28-6bcf-42f0-8776-714def6e4ea2" : {
    },
    "cdf9c731-47d7-4d36-9796-109c997b0e9b" : {
    },
    "e8d0847a-0aca-426d-a2af-cf140a6b21cf" : {
    },
    "7979d121-dd31-4ef3-b936-bdc4a9af27e5" : {
    },
    "17ef2ce7-d885-4257-900e-e2022d9d6fe9" : {
    },
    "030b7e0d-7b64-4e84-89ba-d02c3af5cecd" : {
    },
    "51186875-b712-4a61-b72c-ac4dffca15aa" : {
    },
    "7190e591-eb65-4be8-a657-e039ff7dee37" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);