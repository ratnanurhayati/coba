(function(window, undefined) {
  var dictionary = {
    "5503c96f-f2c9-4ad0-9cad-dd59af748f5f": "List Rekap Log",
    "8e4d9e0e-02bc-4c64-a280-5b613bb0961c": "Ubah-List Rekap Log",
    "7a949020-3324-4dbe-a2fc-0fc25f82a7dc": "Lihat-List Rekap Log",
    "f35c7fd6-45ab-4a15-a9a2-215dfdd7b0f9": "Unduh-Rekap Log",
    "add40d28-6bcf-42f0-8776-714def6e4ea2": "Rekap Log 3",
    "cdf9c731-47d7-4d36-9796-109c997b0e9b": "Rekap Log 2",
    "e8d0847a-0aca-426d-a2af-cf140a6b21cf": "Rekap Log 1",
    "7979d121-dd31-4ef3-b936-bdc4a9af27e5": "Modal Finalisasi-List Rekap Log",
    "17ef2ce7-d885-4257-900e-e2022d9d6fe9": "Finalisasi-List Rekap Log",
    "030b7e0d-7b64-4e84-89ba-d02c3af5cecd": "Hapus - List Rekap Log",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Project Lead",
    "51186875-b712-4a61-b72c-ac4dffca15aa": "Lihat-Riwayat Rekap Log",
    "ca6c08c5-f7bf-4c9d-acb2-6f298b66c49c": "Riwayat Rekap Log",
    "7190e591-eb65-4be8-a657-e039ff7dee37": "Unduh-Tagihan]",
    "e73b655d-d3ec-4dcc-a55c-6e0293422bde": "960 grid - 16 columns",
    "ef07b413-721c-418e-81b1-33a7ed533245": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);